﻿export const BRANCHES = [
    "DPR",
    "AMS",
    "DMT",
    "DMS",
    "DSC"
];


export const COLUMN_GROUPS = [
    {
        key: "env_precos",
        label: "Preços Recebidos"
    },
    {
        key: "env_pend",
        label: "Pendências Recebidas"
    },
    {
        key: "precos_ok",
        label: "Preços Atualizados"
    },
    {
        key: "pendencias_ok",
        label: "Pendências Atualizadas"
    }
];


export const PRICE_PENDING_COLUMNS = [
    {
        key: "industry_global_code",
        label: "Código Global",
        group: null,
        readOnly: true
    },
    {
        key: "laboratory",
        label: "Laboratórios",
        group: null,
        editable: true
    },
    {
        key: "observation",
        label: "Observação",
        group: null,
        editable: true
    },
    {
        key: "env_precos_dpr",
        label: "DPR",
        group: "env_precos"
    },
    {
        key: "env_precos_ams",
        label: "AMS",
        group: "env_precos"
    },
    {
        key: "env_precos_dmt",
        label: "DMT",
        group: "env_precos"
    },
    {
        key: "env_precos_dms",
        label: "DMS",
        group: "env_precos"
    },
    {
        key: "env_precos_dsc",
        label: "DSC",
        group: "env_precos"
    },
    {
        key: "env_pend_dpr",
        label: "DPR",
        group: "env_pend"
    },
    {
        key: "env_pend_ams",
        label: "AMS",
        group: "env_pend"
    },
    {
        key: "env_pend_dmt",
        label: "DMT",
        group: "env_pend"
    },
    {
        key: "env_pend_dms",
        label: "DMS",
        group: "env_pend"
    },
    {
        key: "env_pend_dsc",
        label: "DSC",
        group: "env_pend"
    },
    {
        key: "precos_ok_dpr",
        label: "DPR",
        group: "precos_ok"
    },
    {
        key: "precos_ok_ams",
        label: "AMS",
        group: "precos_ok"
    },
    {
        key: "precos_ok_dmt",
        label: "DMT",
        group: "precos_ok"
    },
    {
        key: "precos_ok_dms",
        label: "DMS",
        group: "precos_ok"
    },
    {
        key: "precos_ok_dsc",
        label: "DSC",
        group: "precos_ok"
    },
    {
        key: "pendencias_ok_dpr",
        label: "DPR",
        group: "pendencias_ok"
    },
    {
        key: "pendencias_ok_ams",
        label: "AMS",
        group: "pendencias_ok"
    },
    {
        key: "pendencias_ok_dmt",
        label: "DMT",
        group: "pendencias_ok"
    },
    {
        key: "pendencias_ok_dms",
        label: "DMS",
        group: "pendencias_ok"
    },
    {
        key: "pendencias_ok_dsc",
        label: "DSC",
        group: "pendencias_ok"
    }
];


export const EMPTY_PRICE_PENDING_ROW = {
    industry_global_code: "",
    laboratory: "",
    observation: "",
    env_precos_dpr: "",
    env_precos_ams: "",
    env_precos_dmt: "",
    env_precos_dms: "",
    env_precos_dsc: "",
    env_pend_dpr: "",
    env_pend_ams: "",
    env_pend_dmt: "",
    env_pend_dms: "",
    env_pend_dsc: "",
    precos_ok_dpr: "",
    precos_ok_ams: "",
    precos_ok_dmt: "",
    precos_ok_dms: "",
    precos_ok_dsc: "",
    pendencias_ok_dpr: "",
    pendencias_ok_ams: "",
    pendencias_ok_dmt: "",
    pendencias_ok_dms: "",
    pendencias_ok_dsc: ""
};


export const PRICE_PENDING_EXPORT_COLUMNS = [
    {
        key: "industry_global_code",
        label: "Código Global"
    },
    {
        key: "laboratory",
        label: "Laboratórios"
    },
    {
        key: "observation",
        label: "Observação"
    },
    {
        key: "env_precos_dpr",
        label: "DPR",
        group: "Preços Recebidos"
    },
    {
        key: "env_precos_ams",
        label: "AMS",
        group: "Preços Recebidos"
    },
    {
        key: "env_precos_dmt",
        label: "DMT",
        group: "Preços Recebidos"
    },
    {
        key: "env_precos_dms",
        label: "DMS",
        group: "Preços Recebidos"
    },
    {
        key: "env_precos_dsc",
        label: "DSC",
        group: "Preços Recebidos"
    },
    {
        key: "env_pend_dpr",
        label: "DPR",
        group: "Pendências Recebidas"
    },
    {
        key: "env_pend_ams",
        label: "AMS",
        group: "Pendências Recebidas"
    },
    {
        key: "env_pend_dmt",
        label: "DMT",
        group: "Pendências Recebidas"
    },
    {
        key: "env_pend_dms",
        label: "DMS",
        group: "Pendências Recebidas"
    },
    {
        key: "env_pend_dsc",
        label: "DSC",
        group: "Pendências Recebidas"
    },
    {
        key: "precos_ok_dpr",
        label: "DPR",
        group: "Preços Atualizados"
    },
    {
        key: "precos_ok_ams",
        label: "AMS",
        group: "Preços Atualizados"
    },
    {
        key: "precos_ok_dmt",
        label: "DMT",
        group: "Preços Atualizados"
    },
    {
        key: "precos_ok_dms",
        label: "DMS",
        group: "Preços Atualizados"
    },
    {
        key: "precos_ok_dsc",
        label: "DSC",
        group: "Preços Atualizados"
    },
    {
        key: "pendencias_ok_dpr",
        label: "DPR",
        group: "Pendências Atualizadas"
    },
    {
        key: "pendencias_ok_ams",
        label: "AMS",
        group: "Pendências Atualizadas"
    },
    {
        key: "pendencias_ok_dmt",
        label: "DMT",
        group: "Pendências Atualizadas"
    },
    {
        key: "pendencias_ok_dms",
        label: "DMS",
        group: "Pendências Atualizadas"
    },
    {
        key: "pendencias_ok_dsc",
        label: "DSC",
        group: "Pendências Atualizadas"
    }
];
